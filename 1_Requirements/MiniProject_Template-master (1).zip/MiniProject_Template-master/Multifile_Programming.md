# Multifile Programming
* Industry projects opten have 5000 to 5 millions of Source lines of Code. And writing everything under one sinlge file is not reader frindly and also it is easy to get lost. 
* A simple solution is to divide the code into multiple files.

