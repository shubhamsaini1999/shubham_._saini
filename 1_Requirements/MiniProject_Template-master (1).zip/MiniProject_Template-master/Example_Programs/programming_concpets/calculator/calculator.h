/**
 * @file calculator.h
 * @author your name (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2021-03-19
 * 
 * @copyright Copyright (c) 2021
 * 
 */

#ifndef __CALCULATOR_H__
#define __CALCULATOR_H__
/**
 * @brief 
 * 
 * @param num1 
 * @param num2 
 * @return int 
 */
int div(int num1, int num2);
#endif 