#include "fun.h"

int sum(int number1, int number2)
{
   return number1 + number2 + 10 ;
}