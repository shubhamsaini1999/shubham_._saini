#include <stdio.h>
#include "complex_calculator.h"
int main()
{
    //TODO Write all the logic for Calculator app
    printf("Complex calculator ");
}