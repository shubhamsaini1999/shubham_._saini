/**
 * @file 0_helloworld.c
 * @author Bharath G
 * @brief  First program
 * @version 0.1
 * @date 2021-03-16
 * 
 * @copyright Copyright (c) 2021
 * 
 */
#include <stdio.h>
/**
 * @brief Print message
 * 
 * @return int 
 */
int main()
{
    int a = 10;

    int sum =20;
    printf("Welcome to STEPin\n");
}