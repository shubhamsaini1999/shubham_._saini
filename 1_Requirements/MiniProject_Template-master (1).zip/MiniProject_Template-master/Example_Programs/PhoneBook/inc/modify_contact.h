/** 
* @file modify_contact.h
*
*/

#ifndef __MODIFY_CONTACT_H__
#define __MODIFY_CONTACT_H__

#include "contact.h"

int modify_contact(char *name, contact_t* update_contact);

#endif  //__MODIFY_CONTACT_H__
