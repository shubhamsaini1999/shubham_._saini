Add the certificates in this folder
* Sololearn Certificate for [Basics of C Programming](https://www.sololearn.com/learning/1089).
* [Cisco NDG](https://www.netacad.com/courses/os-it/ndg-linux-unhatched) to Understand Linux OS and Command Line Interface.
* **Screenshot** of [Github Learning](https://lab.github.com/githubtraining/first-day-on-github) to understand the github usage.
